package com.mbc.pmac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PmacApplication {

	public static void main(String[] args) {
		SpringApplication.run(PmacApplication.class, args);
	}

}
